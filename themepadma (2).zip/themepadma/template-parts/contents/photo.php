<section class="container photo mt-5">
<div class="row text-center">
  <div class="col-sm-5">
    <?php dynamic_sidebar('photoimg1');?>
  </div>
  <div class="col-sm-2">
  <?php dynamic_sidebar('phototitle');?>
  </div>
  <div class="col-sm-5">
  <?php dynamic_sidebar('photoimg2');?>
  </div>
</div>
<div class="row mt-4">
  <div class="col-sm-3">
  <div class="card" style="width: 16rem;">
  <?php dynamic_sidebar('photocard1');?>
</div>
  </div>
  <div class="col-sm-3">
  <div class="card" style="width: 16rem;">
  <?php dynamic_sidebar('photocard2');?>
</div>
  </div>
  <div class="col-sm-3">
  <div class="card" style="width: 16rem;">
  <?php dynamic_sidebar('photocard3');?>
</div>
  </div>
  <div class="col-sm-3">
  <div class="card" style="width: 16rem;">
  <?php dynamic_sidebar('photcard4');?>
</div>
  </div>
  
</div>
</section>