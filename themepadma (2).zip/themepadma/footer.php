<footer class="container-fluid footer_cont mb-5">
  <div class="row">
        <div class="col-sm-8 footer_left">
          <?php dynamic_sidebar('footerleft1');?>
        </div>
        <div class="col-sm-4 footer_right">
        <?php dynamic_sidebar('footerright1');?>
        </div>
  </div>
   
  <div class="row container footer_bottom">
    <div class="col-sm-6">
    <?php dynamic_sidebar('footerbottomleft1');?>
    </div>
    <div class="col-sm-6">
    <?php dynamic_sidebar('footerbottomright1');?>
    </div>
     
  </div>
</footer>
<!-- footer part end -->

<?php wp_footer();?>
</body>
</html>