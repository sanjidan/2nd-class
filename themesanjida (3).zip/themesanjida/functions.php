<?php


wp_enqueue_style('style-1', get_stylesheet_uri());
wp_enqueue_style('style-2', get_template_directory_uri().'/Assets/CSS/bootstrap.min.css');

wp_enqueue_script( 'script-name', get_template_directory_uri() . '/Assets/JS/bootstrap.bundle.min.js', array(), '1.0', true );



add_theme_support( 'title-tag' );
add_theme_support('custom-logo');


add_theme_support( 'post-thumbnails' );



register_nav_menus([
    'top_menu'=>'primary',
    'BM'=>'Footer',
]);

register_sidebar([
    'name'=>'Banner',
    'id'=>'banner',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'Side Image',
    'id'=>'sideimg',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'Side Video',
    'id'=>'sidevideo',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'List',
    'id'=>'list',
    'before_widget'=>'<div id="%1$s" class="widget %2$s list-1">',
    'after_widget'=>'</div>'
]);
register_sidebar([
    'name'=>'Marque',
    'id'=>'marque',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'Footer Main',
    'id'=>'footermain',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'Footer Bottom',
    'id'=>'footerbottom',
    'before_widget'=>'',
    'after_widget'=>''
]);
